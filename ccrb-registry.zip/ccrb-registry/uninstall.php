<?php
defined('WP_UNINSTALL_PLUGIN') || exit;

// Data tables are intentionally preserved (registry data must survive reinstall).
// Remove roles and capabilities only.
remove_role('ccrb_agent');
remove_role('ccrb_responsable');
$admin = get_role('administrator');
if ($admin) {
	foreach (array('ccrb_access', 'ccrb_view', 'ccrb_create', 'ccrb_edit', 'ccrb_validate', 'ccrb_cards', 'ccrb_contributions', 'ccrb_export', 'ccrb_admin') as $cap) {
		$admin->remove_cap($cap);
	}
}
delete_option('ccrb_page_verification');
