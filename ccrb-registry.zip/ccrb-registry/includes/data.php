<?php
defined('ABSPATH') || exit;

function ccrb_now() {
	return current_time('mysql', true);
}

function ccrb_audit($action, $entity, $entity_id, $details = array()) {
	global $wpdb;
	$wpdb->insert(ccrb_table('audit'), array(
		'user_id'    => get_current_user_id() ?: null,
		'action'     => $action,
		'entity'     => $entity,
		'entity_id'  => $entity_id,
		'details'    => wp_json_encode($details),
		'ip'         => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '',
		'created_at' => ccrb_now(),
	));
}

/* ------------------------------------------------------------------ */
/* Residents                                                           */
/* ------------------------------------------------------------------ */

function ccrb_get_resident($id) {
	global $wpdb;
	return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ccrb_table('residents') . ' WHERE id = %d', $id));
}

function ccrb_get_resident_by_no($no) {
	global $wpdb;
	$no = mb_strtoupper(trim($no));
	return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ccrb_table('residents') . ' WHERE resident_no = %s', $no));
}

function ccrb_find_duplicate($nom, $prenoms, $dob, $exclude_id = 0) {
	global $wpdb;
	return $wpdb->get_var($wpdb->prepare(
		'SELECT id FROM ' . ccrb_table('residents') . ' WHERE nom = %s AND prenoms = %s AND date_naissance = %s AND id != %d LIMIT 1',
		$nom, $prenoms, $dob, $exclude_id
	));
}

function ccrb_create_resident($d, &$error = '') {
	global $wpdb;
	if ($dup = ccrb_find_duplicate($d['nom'], $d['prenoms'], $d['date_naissance'])) {
		$error = sprintf('Doublon potentiel : un dossier identique existe déjà (n° %s).', ccrb_get_resident($dup)->resident_no);
		return 0;
	}
	$d['created_at'] = ccrb_now();
	$d['updated_at'] = ccrb_now();
	$d['created_by'] = get_current_user_id() ?: null;
	$d['statut']     = 'en_attente';
	$d['resident_no'] = 'TMP-' . wp_generate_password(16, false, false); // Unique placeholder, replaced below.
	if (! $wpdb->insert(ccrb_table('residents'), $d)) {
		$error = 'Erreur base de données.';
		return 0;
	}
	$id = $wpdb->insert_id;
	$zone = isset($d['code_zone']) && preg_match('/^\d{1,4}$/', $d['code_zone']) ? str_pad($d['code_zone'], 4, '0', STR_PAD_LEFT) : '0000';
	$yy = gmdate('y');
	$t = ccrb_table('residents');
	$serial = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE resident_no LIKE %s", 'CCRB-' . $yy . '-' . $zone . '-%')) + 1;
	$no = sprintf('CCRB-%s-%s-%s', $yy, $zone, str_pad((string) $serial, 4, '0', STR_PAD_LEFT));
	$wpdb->update(ccrb_table('residents'), array('resident_no' => $no, 'code_zone' => $zone), array('id' => $id));
	ccrb_audit('create', 'resident', $id, array('resident_no' => $no));
	return $id;
}

function ccrb_update_resident($id, $d, &$error = '') {
	global $wpdb;
	if (isset($d['nom'], $d['prenoms'], $d['date_naissance'])
		&& $dup = ccrb_find_duplicate($d['nom'], $d['prenoms'], $d['date_naissance'], $id)) {
		$error = sprintf('Doublon potentiel : un dossier identique existe déjà (n° %s).', ccrb_get_resident($dup)->resident_no);
		return false;
	}
	$d['updated_at'] = ccrb_now();
	$ok = $wpdb->update(ccrb_table('residents'), $d, array('id' => $id));
	if ($ok !== false) {
		ccrb_audit('update', 'resident', $id, array_keys($d));
	}
	return $ok !== false;
}

function ccrb_validate_resident($id) {
	global $wpdb;
	$ok = $wpdb->update(ccrb_table('residents'), array(
		'statut'       => 'valide',
		'validated_by' => get_current_user_id() ?: null,
		'validated_at' => ccrb_now(),
		'updated_at'   => ccrb_now(),
	), array('id' => $id, 'statut' => 'en_attente'));
	if ($ok) {
		ccrb_audit('validate', 'resident', $id);
	}
	return (bool) $ok;
}

function ccrb_delete_resident($id) {
	global $wpdb;
	$tr = ccrb_table('residents');
	$tc = ccrb_table('cards');
	$card_ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $tc WHERE resident_id = %d", $id));
	foreach ($card_ids as $cid) {
		$wpdb->delete(ccrb_table('contributions'), array('card_id' => $cid));
	}
	$wpdb->delete($tc, array('resident_id' => $id));
	$wpdb->delete(ccrb_table('requests'), array('resident_id' => $id));
	$ok = $wpdb->delete($tr, array('id' => $id));
	if ($ok) {
		ccrb_audit('delete', 'resident', $id);
	}
	return (bool) $ok;
}

function ccrb_set_resident_status($id, $statut) {
	global $wpdb;
	$ok = $wpdb->update(ccrb_table('residents'), array('statut' => $statut, 'updated_at' => ccrb_now()), array('id' => $id));
	if ($ok !== false) {
		ccrb_audit('status:' . $statut, 'resident', $id);
	}
	return $ok !== false;
}

function ccrb_search_residents($args = array()) {
	global $wpdb;
	$a = wp_parse_args($args, array('q' => '', 'statut' => '', 'per_page' => 20, 'page' => 1));
	$t = ccrb_table('residents');
	$where = '1=1';
	$params = array();
	if ($a['q'] !== '') {
		$like = '%' . $wpdb->esc_like($a['q']) . '%';
		$where .= ' AND (nom LIKE %s OR prenoms LIKE %s OR resident_no LIKE %s OR telephone LIKE %s)';
		$params = array_merge($params, array($like, $like, $like, $like));
	}
	if ($a['statut'] !== '') {
		$where .= ' AND statut = %s';
		$params[] = $a['statut'];
	}
	$total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE $where", $params));
	$offset = ($a['page'] - 1) * $a['per_page'];
	$params[] = $a['per_page'];
	$params[] = $offset;
	$rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE $where ORDER BY created_at DESC LIMIT %d OFFSET %d", $params));
	return array($rows, $total);
}

/* ------------------------------------------------------------------ */
/* Cards                                                               */
/* ------------------------------------------------------------------ */

function ccrb_get_card($id) {
	global $wpdb;
	return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ccrb_table('cards') . ' WHERE id = %d', $id));
}

function ccrb_get_card_by_token($token) {
	global $wpdb;
	return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ccrb_table('cards') . ' WHERE token = %s', $token));
}

function ccrb_get_card_by_no($no) {
	global $wpdb;
	return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ccrb_table('cards') . ' WHERE card_no = %s', $no));
}

function ccrb_resident_cards($resident_id) {
	global $wpdb;
	return $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . ccrb_table('cards') . ' WHERE resident_id = %d ORDER BY id DESC', $resident_id));
}

function ccrb_resident_active_card($resident_id) {
	global $wpdb;
	return $wpdb->get_row($wpdb->prepare(
		'SELECT * FROM ' . ccrb_table('cards') . " WHERE resident_id = %d AND statut = 'active' AND date_expiration >= %s LIMIT 1",
		$resident_id, gmdate('Y-m-d')
	));
}

function ccrb_card_is_active($card) {
	return $card && $card->statut === 'active' && $card->date_expiration >= gmdate('Y-m-d');
}

function ccrb_card_categories() {
	return array(
		'membre'  => 'Membre',
		'bureau'  => 'Bureau',
		'honneur' => "Membre d'honneur",
	);
}

function ccrb_issue_card($resident_id, $categorie = 'membre', &$error = '') {
	global $wpdb;
	$r = ccrb_get_resident($resident_id);
	if (! $r) {
		$error = 'Résident introuvable.';
		return 0;
	}
	if ($r->statut !== 'valide') {
		$error = "L'inscription doit être validée avant la délivrance d'une carte.";
		return 0;
	}
	if (ccrb_resident_active_card($resident_id)) {
		$error = 'Ce résident possède déjà une carte active.';
		return 0;
	}
	if (! array_key_exists($categorie, ccrb_card_categories())) {
		$categorie = 'membre';
	}
	$start = gmdate('Y-m-d');
	$expiry = gmdate('Y-m-d', strtotime($start . ' +2 years -1 day'));
	$wpdb->insert(ccrb_table('cards'), array(
		'card_no'         => 'TMP-' . wp_generate_password(16, false, false),
		'resident_id'     => $resident_id,
		'date_delivrance' => $start,
		'date_expiration' => $expiry,
		'categorie'       => $categorie,
		'statut'          => 'active',
		'token'           => wp_generate_password(32, false, false),
		'created_by'      => get_current_user_id() ?: null,
		'created_at'      => ccrb_now(),
		'updated_at'      => ccrb_now(),
	));
	$id = $wpdb->insert_id;
	if (! $id) {
		$error = 'Erreur base de données.';
		return 0;
	}
	$no = gmdate('ym') . str_pad((string) $id, 5, '0', STR_PAD_LEFT);
	$wpdb->update(ccrb_table('cards'), array('card_no' => $no), array('id' => $id));
	ccrb_audit('issue', 'card', $id, array('card_no' => $no, 'resident_id' => $resident_id));
	return $id;
}

function ccrb_set_card_status($id, $statut) {
	global $wpdb;
	$ok = $wpdb->update(ccrb_table('cards'), array('statut' => $statut, 'updated_at' => ccrb_now()), array('id' => $id));
	if ($ok !== false) {
		ccrb_audit('status:' . $statut, 'card', $id);
	}
	return $ok !== false;
}

function ccrb_search_cards($args = array()) {
	global $wpdb;
	$a = wp_parse_args($args, array('q' => '', 'statut' => '', 'per_page' => 20, 'page' => 1));
	$t = ccrb_table('cards');
	$tr = ccrb_table('residents');
	$where = '1=1';
	$params = array();
	if ($a['q'] !== '') {
		$like = '%' . $wpdb->esc_like($a['q']) . '%';
		$where .= ' AND (c.card_no LIKE %s OR r.nom LIKE %s OR r.prenoms LIKE %s OR r.resident_no LIKE %s)';
		$params = array_merge($params, array($like, $like, $like, $like));
	}
	if ($a['statut'] !== '') {
		$where .= ' AND c.statut = %s';
		$params[] = $a['statut'];
	}
	$total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t c JOIN $tr r ON r.id = c.resident_id WHERE $where", $params));
	$params[] = $a['per_page'];
	$params[] = ($a['page'] - 1) * $a['per_page'];
	$rows = $wpdb->get_results($wpdb->prepare(
		"SELECT c.*, r.nom, r.prenoms, r.resident_no FROM $t c JOIN $tr r ON r.id = c.resident_id WHERE $where ORDER BY c.id DESC LIMIT %d OFFSET %d",
		$params
	));
	return array($rows, $total);
}

/* ------------------------------------------------------------------ */
/* Contributions                                                       */
/* ------------------------------------------------------------------ */

function ccrb_record_contribution($d) {
	global $wpdb;
	$d['recorded_by'] = get_current_user_id() ?: null;
	$d['created_at']  = ccrb_now();
	$ok = $wpdb->insert(ccrb_table('contributions'), $d);
	if ($ok) {
		ccrb_audit('contribution', 'card', (int) $d['card_id'], array('montant' => $d['montant'], 'devise' => $d['devise']));
	}
	return $ok ? $wpdb->insert_id : 0;
}

function ccrb_card_contributions($card_id) {
	global $wpdb;
	return $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . ccrb_table('contributions') . ' WHERE card_id = %d ORDER BY date_paiement DESC', $card_id));
}

/* ------------------------------------------------------------------ */
/* Correction requests + stats                                         */
/* ------------------------------------------------------------------ */

function ccrb_add_request($resident_id, $message) {
	global $wpdb;
	$wpdb->insert(ccrb_table('requests'), array(
		'resident_id' => $resident_id,
		'message'     => $message,
		'created_at'  => ccrb_now(),
	));
	ccrb_audit('correction_request', 'resident', $resident_id);
	return (bool) $wpdb->insert_id;
}

function ccrb_resolve_request($id) {
	global $wpdb;
	$ok = $wpdb->update(ccrb_table('requests'), array('statut' => 'traitee'), array('id' => $id));
	if ($ok) {
		ccrb_audit('resolve_request', 'request', $id);
	}
	return (bool) $ok;
}

function ccrb_stats() {
	global $wpdb;
	$tr = ccrb_table('residents');
	$tc = ccrb_table('cards');
	$tk = ccrb_table('contributions');
	$tq = ccrb_table('requests');
	$today = gmdate('Y-m-d');
	return array(
		'residents_total'   => (int) $wpdb->get_var("SELECT COUNT(*) FROM $tr"),
		'residents_attente' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $tr WHERE statut = 'en_attente'"),
		'residents_valides' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $tr WHERE statut = 'valide'"),
		'cartes_actives'    => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tc WHERE statut = 'active' AND date_expiration >= %s", $today)),
		'cartes_expirees'   => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tc WHERE statut = 'active' AND date_expiration < %s", $today)),
		'cartes_desactivees'=> (int) $wpdb->get_var("SELECT COUNT(*) FROM $tc WHERE statut = 'desactivee'"),
		'cotisations_mois'  => $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(montant),0) FROM $tk WHERE devise='XOF' AND YEAR(date_paiement)=%d AND MONTH(date_paiement)=%d", gmdate('Y'), gmdate('n'))),
		'demandes'          => (int) $wpdb->get_var("SELECT COUNT(*) FROM $tq WHERE statut = 'nouvelle'"),
	);
}
