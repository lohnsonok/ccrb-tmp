<?php
defined('ABSPATH') || exit;

add_action('admin_menu', 'ccrb_admin_menu');
add_action('admin_enqueue_scripts', 'ccrb_admin_assets');
add_action('admin_notices', 'ccrb_admin_notice');
add_action('admin_init', 'ccrb_maybe_print_card');

// Print view must render before wp-admin chrome.
function ccrb_maybe_print_card() {
	if (isset($_GET['page']) && $_GET['page'] === 'ccrb-carte-print') {
		ccrb_page_card_print(); // exits
	}
}

foreach (array('save_resident', 'validate_resident', 'resident_status', 'issue_card', 'card_status', 'renew_card', 'save_contribution', 'export_residents', 'delete_resident', 'resolve_request') as $a) {
	add_action('admin_post_ccrb_' . $a, 'ccrb_handle_' . $a);
}

function ccrb_admin_menu() {
	$ico = 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#a7aaad" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M5 17c0-2 1.8-3.5 4-3.5s4 1.5 4 3.5M15 9h4M15 13h4M15 17h4"/></svg>');
	add_menu_page('CCRB', 'CCRB', 'ccrb_access', 'ccrb', 'ccrb_page_dashboard', $ico, 26);
	add_submenu_page('ccrb', 'Tableau de bord', 'Tableau de bord', 'ccrb_access', 'ccrb', 'ccrb_page_dashboard');
	add_submenu_page('ccrb', 'Résidents', 'Résidents', 'ccrb_view', 'ccrb-residents', 'ccrb_page_residents');
	add_submenu_page('ccrb', 'Nouveau résident', 'Nouveau résident', 'ccrb_create', 'ccrb-resident-edit', 'ccrb_page_resident_edit');
	add_submenu_page('ccrb', 'Cartes', 'Cartes', 'ccrb_cards', 'ccrb-cartes', 'ccrb_page_cards');
	add_submenu_page('ccrb', 'Cotisations', 'Cotisations', 'ccrb_contributions', 'ccrb-cotisations', 'ccrb_page_contributions');
	add_submenu_page('ccrb', 'Journal', 'Journal', 'ccrb_admin', 'ccrb-journal', 'ccrb_page_audit');
	add_submenu_page(null, 'Détail carte', 'Détail carte', 'ccrb_cards', 'ccrb-carte', 'ccrb_page_card_detail');
	add_submenu_page(null, 'Impression carte', 'Impression carte', 'ccrb_cards', 'ccrb-carte-print', 'ccrb_page_card_print');
}

function ccrb_admin_assets($hook) {
	if (strpos((string) $hook, 'ccrb') === false) {
		return;
	}
	wp_enqueue_style('ccrb-admin', CCRB_URL . 'assets/ccrb.css', array(), CCRB_VERSION);
	wp_enqueue_script('ccrb-qrcode', CCRB_URL . 'assets/qrcode.min.js', array(), '1.4.4', true);
	wp_enqueue_media();
}

function ccrb_admin_notice() {
	if (empty($_GET['ccrb_msg'])) {
		return;
	}
	$map = array(
		'saved'        => array('success', 'Dossier enregistré.'),
		'validated'    => array('success', 'Inscription validée.'),
		'status_ok'    => array('success', 'Statut mis à jour.'),
		'card_issued'  => array('success', 'Carte délivrée.'),
		'card_updated' => array('success', 'Carte mise à jour.'),
		'contribution' => array('success', 'Cotisation enregistrée.'),
		'duplicate'    => array('error', 'Doublon détecté : ce résident existe déjà.'),
		'error'        => array('error', isset($_GET['detail']) ? esc_html(wp_unslash($_GET['detail'])) : 'Une erreur est survenue.'),
		'forbidden'    => array('error', 'Action non autorisée.'),
	);
	$m = $map[$_GET['ccrb_msg']] ?? null;
	if ($m) {
		printf('<div class="notice notice-%s is-dismissible"><p>%s</p></div>', $m[0], $m[1]);
	}
}

function ccrb_redirect($page, $msg, $extra = array()) {
	wp_safe_redirect(add_query_arg(array_merge(array('page' => $page, 'ccrb_msg' => $msg), $extra), admin_url('admin.php')));
	exit;
}

function ccrb_field($d, $k, $default = '') {
	return isset($d[$k]) ? sanitize_text_field(wp_unslash($d[$k])) : $default;
}

/* ------------------------------------------------------------------ */
/* Handlers                                                            */
/* ------------------------------------------------------------------ */

function ccrb_resident_data_from_post() {
	$sexe = ccrb_field($_POST, 'sexe');
	return array(
		'nom'            => mb_strtoupper(ccrb_field($_POST, 'nom')),
		'prenoms'        => ccrb_field($_POST, 'prenoms'),
		'date_naissance' => ccrb_field($_POST, 'date_naissance'),
		'lieu_naissance' => ccrb_field($_POST, 'lieu_naissance'),
		'sexe'           => in_array($sexe, array('M', 'F'), true) ? $sexe : 'M',
		'nationalite'    => ccrb_field($_POST, 'nationalite', 'Camerounaise'),
		'adresse_benin'  => ccrb_field($_POST, 'adresse_benin'),
		'telephone'      => ccrb_field($_POST, 'telephone'),
		'profession'     => ccrb_field($_POST, 'profession'),
		'npi'            => ccrb_field($_POST, 'npi'),
		'groupe_sanguin' => in_array(ccrb_field($_POST, 'groupe_sanguin'), array('A+','A-','B+','B-','AB+','AB-','O+','O-'), true) ? ccrb_field($_POST, 'groupe_sanguin') : '',
		'code_zone'      => preg_replace('/\D/', '', ccrb_field($_POST, 'code_zone')),
		'pieces_refs'    => ccrb_field($_POST, 'pieces_refs'),
	);
}

function ccrb_handle_save_resident() {
	$id = isset($_POST['id']) ? absint($_POST['id']) : 0;
	$cap = $id ? 'ccrb_edit' : 'ccrb_create';
	if (! current_user_can($cap)) {
		ccrb_redirect('ccrb-residents', 'forbidden');
	}
	check_admin_referer('ccrb_save_resident_' . $id);

	$d = ccrb_resident_data_from_post();
	foreach (array('nom', 'prenoms', 'date_naissance') as $req) {
		if ($d[$req] === '') {
			ccrb_redirect($id ? 'ccrb-resident-edit' : 'ccrb-resident-edit', 'error', array('detail' => 'Champs obligatoires manquants.', 'id' => $id));
		}
	}

	// Optional photo and signature uploads.
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	if (! empty($_FILES['photo']['name'])) {
		$pid = media_handle_upload('photo', 0);
		if (! is_wp_error($pid)) {
			$d['photo_id'] = $pid;
		}
	}
	if (! empty($_FILES['signature']['name'])) {
		$sid = media_handle_upload('signature', 0);
		if (! is_wp_error($sid)) {
			$d['signature_id'] = $sid;
		}
	}

	if ($id) {
		$err = '';
		ccrb_update_resident($id, $d, $err)
			? ccrb_redirect('ccrb-resident-edit', 'saved', array('id' => $id))
			: ccrb_redirect('ccrb-resident-edit', 'error', array('id' => $id, 'detail' => $err));
	} else {
		$err = '';
		$new = ccrb_create_resident($d, $err);
		$new
			? ccrb_redirect('ccrb-resident-edit', 'saved', array('id' => $new))
			: ccrb_redirect('ccrb-resident-edit', 'error', array('detail' => $err));
	}
}

function ccrb_handle_validate_resident() {
	$id = absint($_GET['id'] ?? 0);
	if (! current_user_can('ccrb_validate')) {
		ccrb_redirect('ccrb-residents', 'forbidden');
	}
	check_admin_referer('ccrb_validate_' . $id);
	ccrb_validate_resident($id)
		? ccrb_redirect('ccrb-residents', 'validated')
		: ccrb_redirect('ccrb-residents', 'error', array('detail' => 'Validation impossible.'));
}

function ccrb_handle_resident_status() {
	$id = absint($_GET['id'] ?? 0);
	$statut = sanitize_key($_GET['to'] ?? '');
	if (! current_user_can('ccrb_edit') || ! in_array($statut, array('valide', 'desactive', 'en_attente'), true)) {
		ccrb_redirect('ccrb-residents', 'forbidden');
	}
	check_admin_referer('ccrb_status_' . $id . '_' . $statut);
	ccrb_set_resident_status($id, $statut);
	ccrb_redirect('ccrb-residents', 'status_ok');
}

function ccrb_handle_delete_resident() {
	$id = absint($_GET['id'] ?? 0);
	if (! current_user_can('ccrb_admin')) {
		ccrb_redirect('ccrb-residents', 'forbidden');
	}
	check_admin_referer('ccrb_delete_' . $id);
	ccrb_delete_resident($id);
	ccrb_redirect('ccrb-residents', 'status_ok');
}

function ccrb_handle_issue_card() {
	$rid = absint($_GET['resident'] ?? 0);
	if (! current_user_can('ccrb_cards')) {
		ccrb_redirect('ccrb-residents', 'forbidden');
	}
	check_admin_referer('ccrb_issue_' . $rid);
	$err = '';
	$cid = ccrb_issue_card($rid, sanitize_key($_GET['cat'] ?? 'membre'), $err);
	$cid
		? ccrb_redirect('ccrb-carte', 'card_issued', array('id' => $cid))
		: ccrb_redirect('ccrb-resident-edit', 'error', array('id' => $rid, 'detail' => $err));
}

function ccrb_handle_card_status() {
	$id = absint($_GET['id'] ?? 0);
	$to = sanitize_key($_GET['to'] ?? '');
	if (! current_user_can('ccrb_cards') || ! in_array($to, array('active', 'desactivee'), true)) {
		ccrb_redirect('ccrb-cartes', 'forbidden');
	}
	check_admin_referer('ccrb_card_' . $id . '_' . $to);
	ccrb_set_card_status($id, $to);
	ccrb_redirect('ccrb-carte', 'card_updated', array('id' => $id));
}

function ccrb_handle_renew_card() {
	$id = absint($_GET['id'] ?? 0);
	if (! current_user_can('ccrb_cards')) {
		ccrb_redirect('ccrb-cartes', 'forbidden');
	}
	check_admin_referer('ccrb_renew_' . $id);
	$card = ccrb_get_card($id);
	if (! $card) {
		ccrb_redirect('ccrb-cartes', 'error', array('detail' => 'Carte introuvable.'));
	}
	// Mark old card replaced, issue a fresh one (validity starts today).
	ccrb_set_card_status($id, 'remplacee');
	global $wpdb;
	$start = gmdate('Y-m-d');
	$wpdb->insert(ccrb_table('cards'), array(
		'card_no'         => 'TMP-' . wp_generate_password(16, false, false),
		'resident_id'     => $card->resident_id,
		'date_delivrance' => $start,
		'date_expiration' => gmdate('Y-m-d', strtotime($start . ' +2 years -1 day')),
		'categorie'       => $card->categorie,
		'statut'          => 'active',
		'token'           => wp_generate_password(32, false, false),
		'created_by'      => get_current_user_id() ?: null,
		'created_at'      => ccrb_now(),
		'updated_at'      => ccrb_now(),
	));
	$cid = $wpdb->insert_id;
	$no = gmdate('ym') . str_pad((string) $cid, 5, '0', STR_PAD_LEFT);
	$wpdb->update(ccrb_table('cards'), array('card_no' => $no), array('id' => $cid));
	ccrb_audit('renew', 'card', $cid, array('card_no' => $no, 'replaces' => $card->card_no));
	ccrb_redirect('ccrb-carte', 'card_issued', array('id' => $cid));
}

function ccrb_handle_save_contribution() {
	if (! current_user_can('ccrb_contributions')) {
		ccrb_redirect('ccrb-cotisations', 'forbidden');
	}
	check_admin_referer('ccrb_save_contribution');
	$card_id = absint($_POST['card_id'] ?? 0);
	$card = ccrb_get_card($card_id);
	if (! $card) {
		ccrb_redirect('ccrb-cotisations', 'error', array('detail' => 'Carte introuvable.'));
	}
	$d = array(
		'card_id'       => $card_id,
		'resident_id'   => $card->resident_id,
		'montant'       => (float) ($_POST['montant'] ?? 0),
		'devise'        => in_array($_POST['devise'] ?? '', array('XOF', 'EUR'), true) ? $_POST['devise'] : 'XOF',
		'date_paiement' => ccrb_field($_POST, 'date_paiement', gmdate('Y-m-d')),
		'note'          => ccrb_field($_POST, 'note'),
	);
	ccrb_record_contribution($d);
	ccrb_redirect('ccrb-carte', 'contribution', array('id' => $card_id));
}

function ccrb_handle_resolve_request() {
	$id = absint($_GET['id'] ?? 0);
	if (! current_user_can('ccrb_edit')) {
		ccrb_redirect('ccrb', 'forbidden');
	}
	check_admin_referer('ccrb_resolve_' . $id);
	ccrb_resolve_request($id);
	ccrb_redirect('ccrb', 'status_ok');
}

function ccrb_handle_export_residents() {
	if (! current_user_can('ccrb_export')) {
		wp_die('Non autorisé');
	}
	check_admin_referer('ccrb_export');
	global $wpdb;
	$rows = $wpdb->get_results('SELECT * FROM ' . ccrb_table('residents') . ' ORDER BY id', ARRAY_A);
	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename=ccrb-residents-' . gmdate('Ymd') . '.csv');
	$out = fopen('php://output', 'w');
	if ($rows) {
		fputcsv($out, array_keys($rows[0]));
		foreach ($rows as $r) {
			fputcsv($out, $r);
		}
	}
	fclose($out);
	ccrb_audit('export', 'resident', 0, array('count' => count($rows)));
	exit;
}

/* ------------------------------------------------------------------ */
/* Views                                                               */
/* ------------------------------------------------------------------ */

function ccrb_status_badge($s) {
	$map = array(
		'en_attente'  => array('En attente', '#d63638'),
		'valide'      => array('Validé', '#00a32a'),
		'desactive'   => array('Désactivé', '#787c82'),
		'active'      => array('Active', '#00a32a'),
		'expiree'     => array('Expirée', '#dba617'),
		'desactivee'  => array('Désactivée', '#787c82'),
		'remplacee'   => array('Remplacée', '#787c82'),
	);
	$m = $map[$s] ?? array($s, '#787c82');
	return sprintf('<span class="ccrb-badge" style="background:%s">%s</span>', esc_attr($m[1]), esc_html($m[0]));
}

function ccrb_effective_card_status($card) {
	if ($card->statut === 'active' && $card->date_expiration < gmdate('Y-m-d')) {
		return 'expiree';
	}
	return $card->statut;
}

function ccrb_page_dashboard() {
	if (! current_user_can('ccrb_access')) {
		wp_die('Accès refusé');
	}
	$s = ccrb_stats();
	global $wpdb;
	$pending = $wpdb->get_results('SELECT * FROM ' . ccrb_table('residents') . " WHERE statut='en_attente' ORDER BY created_at LIMIT 10");
	$requests = $wpdb->get_results('SELECT q.*, r.nom, r.prenoms, r.resident_no FROM ' . ccrb_table('requests') . ' q JOIN ' . ccrb_table('residents') . ' r ON r.id=q.resident_id WHERE q.statut=\'nouvelle\' ORDER BY q.id DESC LIMIT 10');
	?>
	<div class="wrap ccrb-wrap">
		<h1>CCRB — Tableau de bord</h1>
		<div class="ccrb-cards">
			<div class="ccrb-card"><b><?php echo (int) $s['residents_total']; ?></b>Résidents enregistrés</div>
			<div class="ccrb-card"><b><?php echo (int) $s['residents_attente']; ?></b>Inscriptions en attente</div>
			<div class="ccrb-card"><b><?php echo (int) $s['residents_valides']; ?></b>Inscriptions validées</div>
			<div class="ccrb-card"><b><?php echo (int) $s['cartes_actives']; ?></b>Cartes actives</div>
			<div class="ccrb-card"><b><?php echo (int) $s['cartes_expirees']; ?></b>Cartes expirées</div>
			<div class="ccrb-card"><b><?php echo number_format((float) $s['cotisations_mois'], 0, ',', ' '); ?> F</b>Cotisations ce mois</div>
		</div>

		<?php if ($pending) : ?>
			<h2>Inscriptions à valider</h2>
			<table class="widefat striped"><thead><tr><th>N°</th><th>Nom</th><th>Saisi le</th><th></th></tr></thead><tbody>
			<?php foreach ($pending as $r) : ?>
				<tr>
					<td><?php echo esc_html($r->resident_no ?: '—'); ?></td>
					<td><a href="<?php echo esc_url(admin_url('admin.php?page=ccrb-resident-edit&id=' . $r->id)); ?>"><?php echo esc_html($r->nom . ' ' . $r->prenoms); ?></a></td>
					<td><?php echo esc_html(get_date_from_gmt($r->created_at, 'd/m/Y')); ?></td>
					<td>
						<?php if (current_user_can('ccrb_validate')) : ?>
						<a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_validate_resident&id=' . $r->id), 'ccrb_validate_' . $r->id)); ?>">Valider</a>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody></table>
		<?php endif; ?>

		<?php if ($requests) : ?>
			<h2>Demandes de correction (<?php echo (int) $s['demandes']; ?>)</h2>
			<table class="widefat striped"><thead><tr><th>Résident</th><th>Message</th><th>Date</th><th></th></tr></thead><tbody>
			<?php foreach ($requests as $q) : ?>
				<tr>
					<td><a href="<?php echo esc_url(admin_url('admin.php?page=ccrb-resident-edit&id=' . $q->resident_id)); ?>"><?php echo esc_html($q->resident_no . ' — ' . $q->nom . ' ' . $q->prenoms); ?></a></td>
					<td><?php echo esc_html($q->message); ?></td>
					<td><?php echo esc_html(get_date_from_gmt($q->created_at, 'd/m/Y')); ?></td>
					<td>
						<?php if (current_user_can('ccrb_edit')) : ?>
						<a class="button button-small" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_resolve_request&id=' . $q->id), 'ccrb_resolve_' . $q->id)); ?>">Marquer traitée</a>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody></table>
		<?php endif; ?>

		<?php if (current_user_can('ccrb_export')) : ?>
		<p><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_export_residents'), 'ccrb_export')); ?>">Exporter le registre (CSV)</a></p>
		<?php endif; ?>
	</div>
	<?php
}

function ccrb_page_residents() {
	if (! current_user_can('ccrb_view')) {
		wp_die('Accès refusé');
	}
	$q = ccrb_field($_GET, 'q');
	$statut = ccrb_field($_GET, 'statut');
	$page = max(1, absint($_GET['paged'] ?? 1));
	$per = 20;
	list($rows, $total) = ccrb_search_residents(array('q' => $q, 'statut' => $statut, 'per_page' => $per, 'page' => $page));
	$pages = max(1, (int) ceil($total / $per));
	?>
	<div class="wrap ccrb-wrap">
		<h1 class="wp-heading-inline">Résidents</h1>
		<?php if (current_user_can('ccrb_create')) : ?>
		<a href="<?php echo esc_url(admin_url('admin.php?page=ccrb-resident-edit')); ?>" class="page-title-action">Ajouter</a>
		<?php endif; ?>
		<form method="get" class="ccrb-filter">
			<input type="hidden" name="page" value="ccrb-residents">
			<input type="search" name="q" value="<?php echo esc_attr($q); ?>" placeholder="Nom, n°, téléphone…">
			<select name="statut">
				<option value="">Tous statuts</option>
				<?php foreach (array('en_attente' => 'En attente', 'valide' => 'Validé', 'desactive' => 'Désactivé') as $k => $v) : ?>
				<option value="<?php echo esc_attr($k); ?>" <?php selected($statut, $k); ?>><?php echo esc_html($v); ?></option>
				<?php endforeach; ?>
			</select>
			<button class="button">Filtrer</button>
		</form>
		<p><?php echo (int) $total; ?> dossier(s)</p>
		<table class="widefat striped">
			<thead><tr><th>N°</th><th>Photo</th><th>Nom et prénoms</th><th>Né(e) le</th><th>Téléphone</th><th>Statut</th><th>Carte</th><th>Actions</th></tr></thead>
			<tbody>
			<?php foreach ($rows as $r) :
				$card = ccrb_resident_active_card($r->id);
				?>
				<tr>
					<td><?php echo esc_html($r->resident_no); ?></td>
					<td><?php echo $r->photo_id ? wp_get_attachment_image($r->photo_id, array(40, 40)) : '—'; ?></td>
					<td><a href="<?php echo esc_url(admin_url('admin.php?page=ccrb-resident-edit&id=' . $r->id)); ?>"><b><?php echo esc_html($r->nom); ?></b> <?php echo esc_html($r->prenoms); ?></a></td>
					<td><?php echo esc_html(date_i18n('d/m/Y', strtotime($r->date_naissance))); ?></td>
					<td><?php echo esc_html($r->telephone); ?></td>
					<td><?php echo ccrb_status_badge($r->statut); // phpcs:ignore ?></td>
					<td><?php echo $card ? esc_html($card->card_no) : '—'; ?></td>
					<td class="ccrb-actions">
						<a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=ccrb-resident-edit&id=' . $r->id)); ?>">Ouvrir</a>
						<?php if ($r->statut === 'en_attente' && current_user_can('ccrb_validate')) : ?>
							<a class="button button-small button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_validate_resident&id=' . $r->id), 'ccrb_validate_' . $r->id)); ?>">Valider</a>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			<?php if (! $rows) : ?><tr><td colspan="8">Aucun dossier.</td></tr><?php endif; ?>
			</tbody>
		</table>
		<?php if ($pages > 1) : ?>
		<div class="tablenav"><div class="tablenav-pages">
			<?php for ($i = 1; $i <= $pages; $i++) : ?>
				<a class="button button-small <?php echo $i === $page ? 'button-primary' : ''; ?>" href="<?php echo esc_url(add_query_arg(array('page' => 'ccrb-residents', 'q' => $q, 'statut' => $statut, 'paged' => $i), admin_url('admin.php'))); ?>"><?php echo (int) $i; ?></a>
			<?php endfor; ?>
		</div></div>
		<?php endif; ?>
	</div>
	<?php
}

function ccrb_page_resident_edit() {
	$id = absint($_GET['id'] ?? 0);
	if ($id && ! current_user_can('ccrb_view')) {
		wp_die('Accès refusé');
	}
	if (! $id && ! current_user_can('ccrb_create')) {
		wp_die('Accès refusé');
	}
	$r = $id ? ccrb_get_resident($id) : null;
	if ($id && ! $r) {
		wp_die('Dossier introuvable');
	}
	$editable = $id ? current_user_can('ccrb_edit') : current_user_can('ccrb_create');
	$cards = $id ? ccrb_resident_cards($id) : array();
	$dis = $editable ? '' : ' disabled';
	?>
	<div class="wrap ccrb-wrap">
		<h1><?php echo $r ? esc_html($r->resident_no . ' — ' . $r->nom . ' ' . $r->prenoms) : 'Nouveau résident'; ?></h1>
		<?php if ($r) : ?>
			<p>Statut : <?php echo ccrb_status_badge($r->statut); // phpcs:ignore ?>
			<?php if ($r->statut === 'en_attente' && current_user_can('ccrb_validate')) : ?>
				<a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_validate_resident&id=' . $r->id), 'ccrb_validate_' . $r->id)); ?>">Valider l'inscription</a>
			<?php endif; ?>
			<?php if ($r->statut === 'valide' && current_user_can('ccrb_edit')) : ?>
				<a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_resident_status&id=' . $r->id . '&to=desactive'), 'ccrb_status_' . $r->id . '_desactive')); ?>" onclick="return confirm('Désactiver ce dossier ?')">Désactiver</a>
			<?php endif; ?>
			<?php if (current_user_can('ccrb_admin')) : ?>
				<a class="button ccrb-danger" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_delete_resident&id=' . $r->id), 'ccrb_delete_' . $r->id)); ?>" onclick="return confirm('SUPPRIMER définitivement ce dossier et ses cartes ?')">Supprimer</a>
			<?php endif; ?>
			</p>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" class="ccrb-form">
			<input type="hidden" name="action" value="ccrb_save_resident">
			<input type="hidden" name="id" value="<?php echo (int) $id; ?>">
			<?php wp_nonce_field('ccrb_save_resident_' . $id); ?>
			<table class="form-table">
				<tr><th>Nom *</th><td><input type="text" name="nom" required value="<?php echo esc_attr($r->nom ?? ''); ?>" <?php echo $dis; ?>></td>
					<th>Prénoms *</th><td><input type="text" name="prenoms" required value="<?php echo esc_attr($r->prenoms ?? ''); ?>" <?php echo $dis; ?>></td></tr>
				<tr><th>Date de naissance *</th><td><input type="date" name="date_naissance" required value="<?php echo esc_attr($r->date_naissance ?? ''); ?>" <?php echo $dis; ?>></td>
					<th>Lieu de naissance</th><td><input type="text" name="lieu_naissance" value="<?php echo esc_attr($r->lieu_naissance ?? ''); ?>" <?php echo $dis; ?>></td></tr>
				<tr><th>Sexe</th><td><select name="sexe" <?php echo $dis; ?>><option value="M" <?php selected($r->sexe ?? '', 'M'); ?>>Masculin</option><option value="F" <?php selected($r->sexe ?? '', 'F'); ?>>Féminin</option></select></td>
					<th>Nationalité</th><td><input type="text" name="nationalite" value="<?php echo esc_attr($r->nationalite ?? 'Camerounaise'); ?>" <?php echo $dis; ?>></td></tr>
				<tr><th>Adresse au Bénin</th><td><input type="text" name="adresse_benin" value="<?php echo esc_attr($r->adresse_benin ?? ''); ?>" <?php echo $dis; ?>></td>
					<th>Téléphone</th><td><input type="text" name="telephone" value="<?php echo esc_attr($r->telephone ?? ''); ?>" <?php echo $dis; ?>></td></tr>
				<tr><th>Profession</th><td><input type="text" name="profession" value="<?php echo esc_attr($r->profession ?? ''); ?>" <?php echo $dis; ?>></td>
					<th>NPI étranger</th><td><input type="text" name="npi" value="<?php echo esc_attr($r->npi ?? ''); ?>" <?php echo $dis; ?>></td></tr>
				<tr><th>Groupe sanguin</th><td><select name="groupe_sanguin" <?php echo $dis; ?>><option value="">—</option><?php foreach (array('A+','A-','B+','B-','AB+','AB-','O+','O-') as $gs) : ?><option value="<?php echo $gs; ?>" <?php selected($r->groupe_sanguin ?? '', $gs); ?>><?php echo $gs; ?></option><?php endforeach; ?></select></td>
					<th>Code zone / antenne</th><td><input type="text" name="code_zone" maxlength="4" placeholder="0000" value="<?php echo esc_attr($r->code_zone ?? ''); ?>" <?php echo $dis; ?>></td></tr>
				<tr><th>Pièces justificatives</th><td colspan="3"><input type="text" name="pieces_refs" placeholder="Passeport n°…, acte de naissance…" value="<?php echo esc_attr($r->pieces_refs ?? ''); ?>" <?php echo $dis; ?>></td></tr>
				<tr><th>Photo</th><td>
					<?php if (! empty($r->photo_id)) : echo wp_get_attachment_image($r->photo_id, array(80, 80)) . '<br>'; endif; ?>
					<?php if ($editable) : ?><input type="file" name="photo" accept="image/*"><?php endif; ?>
				</td>
				<th>Signature titulaire</th><td>
					<?php if (! empty($r->signature_id)) : echo wp_get_attachment_image($r->signature_id, array(80, 40)) . '<br>'; endif; ?>
					<?php if ($editable) : ?><input type="file" name="signature" accept="image/*"><?php endif; ?>
				</td></tr>
			</table>
			<?php if ($editable) : ?><button class="button button-primary">Enregistrer</button><?php endif; ?>
		</form>

		<?php if ($r) : ?>
		<h2>Cartes communautaires</h2>
		<table class="widefat striped"><thead><tr><th>N° carte</th><th>Catégorie</th><th>Délivrée</th><th>Expire</th><th>Statut</th><th></th></tr></thead><tbody>
		<?php foreach ($cards as $c) : $cats = ccrb_card_categories(); ?>
			<tr>
				<td><?php echo esc_html($c->card_no); ?></td>
				<td><?php echo esc_html($cats[$c->categorie] ?? $c->categorie); ?></td>
				<td><?php echo esc_html(date_i18n('d/m/Y', strtotime($c->date_delivrance))); ?></td>
				<td><?php echo esc_html(date_i18n('d/m/Y', strtotime($c->date_expiration))); ?></td>
				<td><?php echo ccrb_status_badge(ccrb_effective_card_status($c)); // phpcs:ignore ?></td>
				<td><a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=ccrb-carte&id=' . $c->id)); ?>">Détail</a></td>
			</tr>
		<?php endforeach; ?>
		<?php if (! $cards) : ?><tr><td colspan="6">Aucune carte.</td></tr><?php endif; ?>
		</tbody></table>
		<?php if ($r->statut === 'valide' && current_user_can('ccrb_cards') && ! ccrb_resident_active_card($r->id)) : ?>
			<form method="get" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="ccrb-inline">
				<input type="hidden" name="action" value="ccrb_issue_card">
				<input type="hidden" name="resident" value="<?php echo (int) $r->id; ?>">
				<?php wp_nonce_field('ccrb_issue_' . $r->id); ?>
				<select name="cat">
					<?php foreach (ccrb_card_categories() as $k => $v) : ?><option value="<?php echo esc_attr($k); ?>"><?php echo esc_html($v); ?></option><?php endforeach; ?>
				</select>
				<button class="button button-primary">Délivrer une carte</button>
			</form>
		<?php endif; ?>
		<?php endif; ?>
	</div>
	<?php
}

function ccrb_page_cards() {
	if (! current_user_can('ccrb_cards')) {
		wp_die('Accès refusé');
	}
	$q = ccrb_field($_GET, 'q');
	$statut = ccrb_field($_GET, 'statut');
	$page = max(1, absint($_GET['paged'] ?? 1));
	list($rows, $total) = ccrb_search_cards(array('q' => $q, 'statut' => $statut, 'page' => $page));
	?>
	<div class="wrap ccrb-wrap">
		<h1>Cartes communautaires</h1>
		<form method="get" class="ccrb-filter">
			<input type="hidden" name="page" value="ccrb-cartes">
			<input type="search" name="q" value="<?php echo esc_attr($q); ?>" placeholder="N° carte, nom…">
			<select name="statut">
				<option value="">Tous statuts</option>
				<?php foreach (array('active' => 'Active', 'desactivee' => 'Désactivée', 'remplacee' => 'Remplacée') as $k => $v) : ?>
				<option value="<?php echo esc_attr($k); ?>" <?php selected($statut, $k); ?>><?php echo esc_html($v); ?></option>
				<?php endforeach; ?>
			</select>
			<button class="button">Filtrer</button>
		</form>
		<table class="widefat striped">
			<thead><tr><th>N° carte</th><th>Titulaire</th><th>N° résident</th><th>Délivrée</th><th>Expire</th><th>Statut</th><th></th></tr></thead>
			<tbody>
			<?php foreach ($rows as $c) : ?>
				<tr>
					<td><?php echo esc_html($c->card_no); ?></td>
					<td><?php echo esc_html($c->nom . ' ' . $c->prenoms); ?></td>
					<td><?php echo esc_html($c->resident_no); ?></td>
					<td><?php echo esc_html(date_i18n('d/m/Y', strtotime($c->date_delivrance))); ?></td>
					<td><?php echo esc_html(date_i18n('d/m/Y', strtotime($c->date_expiration))); ?></td>
					<td><?php echo ccrb_status_badge(ccrb_effective_card_status($c)); // phpcs:ignore ?></td>
					<td><a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=ccrb-carte&id=' . $c->id)); ?>">Détail</a></td>
				</tr>
			<?php endforeach; ?>
			<?php if (! $rows) : ?><tr><td colspan="7">Aucune carte.</td></tr><?php endif; ?>
			</tbody>
		</table>
	</div>
	<?php
}

function ccrb_page_card_detail() {
	if (! current_user_can('ccrb_cards')) {
		wp_die('Accès refusé');
	}
	$id = absint($_GET['id'] ?? 0);
	$c = ccrb_get_card($id);
	if (! $c) {
		wp_die('Carte introuvable');
	}
	$r = ccrb_get_resident($c->resident_id);
	$contrib = ccrb_card_contributions($id);
	$eff = ccrb_effective_card_status($c);
	?>
	<div class="wrap ccrb-wrap">
		<h1>Carte <?php echo esc_html($c->card_no); ?></h1>
		<p><?php echo ccrb_status_badge($eff); // phpcs:ignore ?></p>
		<table class="form-table">
			<tr><th>Titulaire</th><td><a href="<?php echo esc_url(admin_url('admin.php?page=ccrb-resident-edit&id=' . $r->id)); ?>"><?php echo esc_html($r->nom . ' ' . $r->prenoms); ?></a> (<?php echo esc_html($r->resident_no); ?>)</td></tr>
			<tr><th>Catégorie</th><td><?php $cats = ccrb_card_categories(); echo esc_html($cats[$c->categorie] ?? $c->categorie); ?></td></tr>
			<tr><th>Délivrée le</th><td><?php echo esc_html(date_i18n('d/m/Y', strtotime($c->date_delivrance))); ?></td></tr>
			<tr><th>Expire le</th><td><?php echo esc_html(date_i18n('d/m/Y', strtotime($c->date_expiration))); ?></td></tr>
			<tr><th>Lien de vérification (QR)</th><td><code><?php echo esc_html(ccrb_card_verify_url($c)); ?></code>
				<div id="ccrb-qr" style="margin-top:8px"></div></td></tr>
		</table>
		<p>
			<a class="button" target="_blank" href="<?php echo esc_url(admin_url('admin.php?page=ccrb-carte-print&id=' . $id)); ?>">Imprimer la carte</a>
			<?php if ($eff === 'active' || $eff === 'expiree') : ?>
				<a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_card_status&id=' . $id . '&to=desactivee'), 'ccrb_card_' . $id . '_desactivee')); ?>" onclick="return confirm('Désactiver cette carte ?')">Désactiver</a>
			<?php endif; ?>
			<?php if ($eff === 'desactivee') : ?>
				<a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_card_status&id=' . $id . '&to=active'), 'ccrb_card_' . $id . '_active')); ?>">Réactiver</a>
			<?php endif; ?>
			<a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=ccrb_renew_card&id=' . $id), 'ccrb_renew_' . $id)); ?>">Renouveler</a>
		</p>

		<h2>Cotisations</h2>
		<table class="widefat striped"><thead><tr><th>Date</th><th>Montant</th><th>Note</th></tr></thead><tbody>
		<?php foreach ($contrib as $k) : ?>
			<tr><td><?php echo esc_html(date_i18n('d/m/Y', strtotime($k->date_paiement))); ?></td>
				<td><?php echo esc_html(number_format((float) $k->montant, 0, ',', ' ') . ' ' . $k->devise); ?></td>
				<td><?php echo esc_html($k->note); ?></td></tr>
		<?php endforeach; ?>
		<?php if (! $contrib) : ?><tr><td colspan="3">Aucune cotisation enregistrée.</td></tr><?php endif; ?>
		</tbody></table>
		<h3>Enregistrer une cotisation</h3>
		<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="ccrb-inline">
			<input type="hidden" name="action" value="ccrb_save_contribution">
			<input type="hidden" name="card_id" value="<?php echo (int) $id; ?>">
			<?php wp_nonce_field('ccrb_save_contribution'); ?>
			<input type="number" name="montant" min="0" step="1" required placeholder="Montant">
			<select name="devise"><option value="XOF">FCFA</option><option value="EUR">EUR</option></select>
			<input type="date" name="date_paiement" value="<?php echo esc_attr(gmdate('Y-m-d')); ?>">
			<input type="text" name="note" placeholder="Note (optionnel)">
			<button class="button button-primary">Enregistrer</button>
		</form>
	</div>
	<script>
	document.addEventListener('DOMContentLoaded', function () {
		if (typeof qrcode !== 'undefined') {
			var q = qrcode(0, 'M');
			q.addData(<?php echo wp_json_encode(ccrb_card_verify_url($c)); ?>);
			q.make();
			document.getElementById('ccrb-qr').innerHTML = q.createImgTag(4);
		}
	});
	</script>
	<?php
}

function ccrb_page_card_print() {
	if (! current_user_can('ccrb_cards')) {
		wp_die('Accès refusé');
	}
	$id = absint($_GET['id'] ?? 0);
	$c = ccrb_get_card($id);
	if (! $c) {
		wp_die('Carte introuvable');
	}
	$r = ccrb_get_resident($c->resident_id);
	$photo = $r->photo_id ? wp_get_attachment_image_url($r->photo_id, 'medium') : '';
	$sign = ! empty($r->signature_id) ? wp_get_attachment_image_url($r->signature_id, 'medium') : '';
	$cats = ccrb_card_categories();
	$cat_label = strtoupper($cats[$c->categorie] ?? $c->categorie);
	$bg = array(
		'membre'  => '#ffffff',
		'bureau'  => 'linear-gradient(135deg,#caa53d 0%,#e8d48b 45%,#b8912f 100%)',
		'honneur' => 'linear-gradient(135deg,#e6ecd9 0%,#f4f7ea 50%,#dde7c8 100%)',
	);
	$card_bg = $bg[$c->categorie] ?? $bg['membre'];
	$micro = esc_html(str_repeat('CONSEIL DES CAMEROUNAIS RÉSIDENTS AU BÉNIN — CCRB — ', 8));
	?><!doctype html>
<html><head><meta charset="utf-8"><title>Carte <?php echo esc_html($c->card_no); ?></title>
<style>
	*{box-sizing:border-box}
	body{font-family:Arial,Helvetica,sans-serif;background:#e8e8e8;margin:0;padding:24px;color:#111}
	.sheet{max-width:880px;margin:0 auto}
	.card{width:856px;height:540px;border-radius:18px;position:relative;overflow:hidden;margin:0 auto 28px;padding:18px 22px 34px;background:<?php echo $card_bg; ?>;box-shadow:0 2px 10px rgba(0,0,0,.25);font-size:13px;line-height:1.25}
	.card .map{position:absolute;top:60px;right:-30px;width:430px;height:430px;background:url('<?php echo esc_url(CCRB_URL . 'assets/carte-cm.svg'); ?>') no-repeat center/contain;opacity:.14;pointer-events:none}
	.verso .map{top:80px;left:330px;right:auto;opacity:.12}
	.flag{display:inline-flex;width:58px;height:40px;border-radius:4px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.3);vertical-align:top}
	.flag i{flex:1}.flag .g{background:#007a5e}.flag .r{background:#ce1126;position:relative}.flag .y{background:#fcd116}
	.flag .r::after{content:'';position:absolute;top:50%;left:50%;width:15px;height:15px;transform:translate(-50%,-50%);background:#fcd116;clip-path:polygon(50% 0%,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%)}
	.head{display:flex;align-items:flex-start;justify-content:space-between;position:relative}
	.head h1{margin:0;font-size:26px;font-weight:800;letter-spacing:1px;flex:1;text-align:center;padding-top:2px}
	.head h1 span{display:block;font-size:12px;font-weight:600;letter-spacing:3px;margin-top:2px}
	.head .logo{width:64px;margin-top:-6px}
	.lab{font-size:10px;color:#333;font-style:italic;font-weight:600}
	.val{font-size:14px;font-weight:700;margin:1px 0 10px}
	.recto .body{display:flex;gap:18px;margin-top:14px;position:relative}
	.photo{width:196px;height:246px;object-fit:cover;border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.3);background:#ddd}
	.photo.ph{display:flex;align-items:center;justify-content:center;color:#999;font-size:11px}
	.cols{display:flex;flex:1;gap:22px}
	.col{flex:1}
	.twocol{display:flex;gap:12px}.twocol>div{flex:1}
	.holder-no{color:#0a5c8c;font-size:15px}
	.sign{position:absolute;left:330px;bottom:64px;text-align:center;width:200px}
	.sign img{max-width:170px;max-height:42px;display:block;margin:0 auto}
	.sign .lab{display:block}
	.foot{position:absolute;left:0;right:0;bottom:18px;text-align:center;font-size:16px;font-weight:800;letter-spacing:.5px}
	.foot span{display:block;font-size:9px;font-weight:600;letter-spacing:2px}
	.micro{position:absolute;left:0;right:0;bottom:0;height:12px;font-size:6px;letter-spacing:1px;white-space:nowrap;overflow:hidden;color:#333}
	/* ---- verso ---- */
	.verso .head2{text-align:center;font-size:17px;font-weight:800;letter-spacing:.5px;margin-bottom:2px}
	.verso .head2 span{display:block;font-size:9px;font-weight:600;letter-spacing:2px;margin-bottom:6px}
	.verso .body{display:flex;gap:26px;position:relative;margin-top:6px}
	.vleft{width:340px}
	.qrwrap{display:flex;align-items:center;gap:6px;margin-bottom:10px}
	.qrwrap .vnum{writing-mode:vertical-rl;transform:rotate(180deg);font-weight:700;font-size:13px;letter-spacing:2px}
	.qrbox{background:#fff;padding:6px;border:1px solid #ccc}
	.qrbox img{display:block;width:118px;height:118px}
	.vright{flex:1;position:relative}
	.chip{position:absolute;top:-2px;right:6px;width:104px}
	.vtxt{font-size:14px;font-weight:700;margin:64px 0 10px}
	.vtxt small{display:block;font-size:10px;font-weight:400;font-style:italic;color:#333}
	.contact{font-size:13px;font-weight:700;margin-top:14px}
	.pres{position:absolute;right:0;bottom:8px;text-align:center;width:250px}
	.pres .t{font-size:13px;font-weight:800}
	.pres .t small{display:block;font-size:9px;font-weight:600}
	.pres img{max-height:46px;margin:0 auto;display:block}
	.pres .n{font-size:13px;font-weight:700}
	.foot2{position:absolute;left:0;right:0;bottom:18px;text-align:center;font-size:14px;font-weight:800;letter-spacing:.5px}
	.foot2 span{font-size:9px;font-weight:600;letter-spacing:2px}
	.toolbar{text-align:center;margin-bottom:16px}
	.toolbar button{font-size:15px;padding:8px 22px;cursor:pointer}
	.sidelabel{text-align:center;font-size:12px;color:#666;margin:0 0 6px;font-weight:700;letter-spacing:2px}
	@media print{
		body{background:#fff;padding:0}
		.toolbar,.sidelabel{display:none}
		.card{box-shadow:none;margin:0 auto 8mm;page-break-inside:avoid}
	}
	</style></head><body>
<div class="sheet">
<div class="toolbar"><button onclick="window.print()">Imprimer</button></div>
<p class="sidelabel">RECTO</p>
<div class="card recto">
	<div class="map"></div>
	<div class="head">
		<span class="flag"><i class="g"></i><i class="r"></i><i class="y"></i></span>
		<h1>CARTE COMMUNAUTAIRE<span>COMMUNITY CARD</span></h1>
		<img class="logo" src="<?php echo esc_url(CCRB_URL . 'assets/logo-ccrb.png'); ?>" alt="CCRB">
	</div>
	<div class="body">
		<?php if ($photo) : ?>
			<img class="photo" src="<?php echo esc_url($photo); ?>" alt="">
		<?php else : ?>
			<div class="photo ph">PHOTO</div>
		<?php endif; ?>
		<div class="cols">
			<div class="col">
				<div class="lab">Nom / Surname</div><div class="val"><?php echo esc_html($r->nom); ?></div>
				<div class="lab">Prénoms / First names</div><div class="val"><?php echo esc_html($r->prenoms); ?></div>
				<div class="lab">Date de naissance / Date of birth</div><div class="val"><?php echo esc_html(date_i18n('d/m/Y', strtotime($r->date_naissance))); ?></div>
				<div class="twocol">
					<div><div class="lab">Sexe / Sex</div><div class="val"><?php echo esc_html($r->sexe); ?></div></div>
					<div><div class="lab">Lieu de naissance / Place of birth</div><div class="val"><?php echo esc_html($r->lieu_naissance); ?></div></div>
				</div>
				<div class="lab">Adresse / Adress</div><div class="val" style="margin-bottom:2px"><?php echo esc_html($r->adresse_benin); ?><?php if ($r->telephone) : ?><br><?php echo esc_html($r->telephone); ?><?php endif; ?></div>
				<div class="lab">N° d'identification du titulaire / Holder's N°</div><div class="val holder-no"><?php echo esc_html($r->resident_no); ?></div>
			</div>
			<div class="col">
				<div class="lab">Date de délivrance / Date of issue</div><div class="val"><?php echo esc_html(date_i18n('d/m/Y', strtotime($c->date_delivrance))); ?></div>
				<div class="lab">Date d'expiration / Date of expiry</div><div class="val"><?php echo esc_html(date_i18n('d/m/Y', strtotime($c->date_expiration))); ?></div>
				<div class="lab">Occupation</div><div class="val"><?php echo esc_html($cat_label); ?></div>
				<div class="lab">Lieu de délivrance / Place of issue</div><div class="val">COTONOU</div>
				<div class="lab">N° de carte / Card N°</div><div class="val"><?php echo esc_html($c->card_no); ?></div>
			</div>
		</div>
	</div>
	<div class="sign">
		<?php if ($sign) : ?><img src="<?php echo esc_url($sign); ?>" alt=""><?php endif; ?>
		<span class="lab">Signature du titulaire / Bearer signature</span>
	</div>
	<div class="foot">CONSEIL DES CAMEROUNAIS RÉSIDENTS AU BÉNIN<span>COUNCIL OF CAMEROONIANS RESIDING IN BENIN REPUBLIC</span></div>
	<div class="micro"><?php echo $micro; // phpcs:ignore ?></div>
</div>
<p class="sidelabel">VERSO</p>
<div class="card verso">
	<div class="map"></div>
	<div class="head2">CONSEIL DES CAMEROUNAIS RÉSIDENTS AU BÉNIN<span>COUNCIL OF CAMEROONIANS RESIDING IN BENIN REPUBLIC</span></div>
	<div class="body">
		<div class="vleft">
			<div class="qrwrap">
				<div class="vnum"><?php echo esc_html($c->card_no); ?></div>
				<div class="qrbox" id="qr"></div>
			</div>
			<div class="lab" style="font-size:12px;font-style:normal;font-weight:800">Éléments additionnels / Additional comments</div>
			<div class="lab">Numéro Personnel d'indentification Étranger /<br>Foreign National Identification Number</div><div class="val"><?php echo esc_html($r->npi); ?></div>
			<div class="lab">Profession / Job</div><div class="val"><?php echo esc_html($r->profession); ?></div>
			<div class="lab">Groupe sanguin / Blood group</div><div class="val"><?php echo esc_html($r->groupe_sanguin); ?></div>
		</div>
		<div class="vright">
			<img class="chip" src="<?php echo esc_url(CCRB_URL . 'assets/chip.png'); ?>" alt="">
			<div class="vtxt">Cette carte est la propriété du CCRB. Elle est personnelle et non cessible.<small>This card remains the property of CCRB. It is personal and non-transferable.</small></div>
			<div class="vtxt" style="margin-top:6px">En cas de perte ou de découverte, merci de la retourner au CCRB.<small>If found, please return it to the CCRB.</small></div>
			<div class="contact">CCRB Contact :<br>+229 01 22 22 22 22</div>
			<div class="pres">
				<div class="t">LA PRÉSIDENTE DU CCRB<small>THE PRESIDENT</small></div>
				<img src="<?php echo esc_url(CCRB_URL . 'assets/sign-presidente.png'); ?>" alt="">
				<div class="n">Mme SIKEDI Victoire Davison</div>
			</div>
		</div>
	</div>
	<div class="foot2">CARTE COMMUNAUTAIRE <span>COMMUNITY CARD</span></div>
	<div class="micro"><?php echo $micro; // phpcs:ignore ?></div>
</div>
</div>
<script src="<?php echo esc_url(CCRB_URL . 'assets/qrcode.min.js'); ?>"></script>
<script>
	var q = qrcode(0, 'M');
	q.addData(<?php echo wp_json_encode(ccrb_card_verify_url($c)); ?>);
	q.make();
	document.getElementById('qr').innerHTML = q.createImgTag(3);
</script>
</body></html>
	<?php
	exit;
}

function ccrb_page_contributions() {
	if (! current_user_can('ccrb_contributions')) {
		wp_die('Accès refusé');
	}
	global $wpdb;
	$t = ccrb_table('contributions');
	$tc = ccrb_table('cards');
	$tr = ccrb_table('residents');
	$rows = $wpdb->get_results("SELECT k.*, c.card_no, r.nom, r.prenoms FROM $t k JOIN $tc c ON c.id=k.card_id JOIN $tr r ON r.id=k.resident_id ORDER BY k.id DESC LIMIT 100");
	?>
	<div class="wrap ccrb-wrap">
		<h1>Cotisations</h1>
		<p>Les cotisations s'enregistrent depuis la fiche d'une carte.</p>
		<table class="widefat striped"><thead><tr><th>Date</th><th>Carte</th><th>Titulaire</th><th>Montant</th><th>Note</th></tr></thead><tbody>
		<?php foreach ($rows as $k) : ?>
			<tr>
				<td><?php echo esc_html(date_i18n('d/m/Y', strtotime($k->date_paiement))); ?></td>
				<td><a href="<?php echo esc_url(admin_url('admin.php?page=ccrb-carte&id=' . $k->card_id)); ?>"><?php echo esc_html($k->card_no); ?></a></td>
				<td><?php echo esc_html($k->nom . ' ' . $k->prenoms); ?></td>
				<td><?php echo esc_html(number_format((float) $k->montant, 0, ',', ' ') . ' ' . $k->devise); ?></td>
				<td><?php echo esc_html($k->note); ?></td>
			</tr>
		<?php endforeach; ?>
		<?php if (! $rows) : ?><tr><td colspan="5">Aucune cotisation.</td></tr><?php endif; ?>
		</tbody></table>
	</div>
	<?php
}

function ccrb_page_audit() {
	if (! current_user_can('ccrb_admin')) {
		wp_die('Accès refusé');
	}
	global $wpdb;
	$rows = $wpdb->get_results('SELECT a.*, u.display_name FROM ' . ccrb_table('audit') . ' a LEFT JOIN ' . $wpdb->users . ' u ON u.ID=a.user_id ORDER BY a.id DESC LIMIT 200');
	?>
	<div class="wrap ccrb-wrap">
		<h1>Journal d'activité</h1>
		<table class="widefat striped"><thead><tr><th>Date</th><th>Utilisateur</th><th>Action</th><th>Objet</th><th>Détails</th></tr></thead><tbody>
		<?php foreach ($rows as $a) : ?>
			<tr>
				<td><?php echo esc_html(get_date_from_gmt($a->created_at, 'd/m/Y H:i')); ?></td>
				<td><?php echo esc_html($a->display_name ?: '—'); ?></td>
				<td><?php echo esc_html($a->action); ?></td>
				<td><?php echo esc_html($a->entity . ' #' . $a->entity_id); ?></td>
				<td><code><?php echo esc_html($a->details); ?></code></td>
			</tr>
		<?php endforeach; ?>
		<?php if (! $rows) : ?><tr><td colspan="5">Journal vide.</td></tr><?php endif; ?>
		</tbody></table>
	</div>
	<?php
}
