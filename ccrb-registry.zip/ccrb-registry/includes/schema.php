<?php
defined('ABSPATH') || exit;

function ccrb_table($name) {
	global $wpdb;
	return $wpdb->prefix . 'ccrb_' . $name;
}

function ccrb_install_tables() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$c = $wpdb->get_charset_collate();
	$p = $wpdb->prefix . 'ccrb_';

	dbDelta("CREATE TABLE {$p}residents (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		resident_no VARCHAR(20) NOT NULL,
		nom VARCHAR(100) NOT NULL,
		prenoms VARCHAR(150) NOT NULL,
		date_naissance DATE NOT NULL,
		lieu_naissance VARCHAR(150) NOT NULL DEFAULT '',
		sexe VARCHAR(1) NOT NULL DEFAULT 'M',
		nationalite VARCHAR(80) NOT NULL DEFAULT 'Camerounaise',
		adresse_benin VARCHAR(255) NOT NULL DEFAULT '',
		telephone VARCHAR(40) NOT NULL DEFAULT '',
		profession VARCHAR(120) NOT NULL DEFAULT '',
		npi VARCHAR(32) NOT NULL DEFAULT '',
		groupe_sanguin VARCHAR(4) NOT NULL DEFAULT '',
		code_zone VARCHAR(4) NOT NULL DEFAULT '0000',
		photo_id BIGINT UNSIGNED NULL,
		signature_id BIGINT UNSIGNED NULL,
		pieces_refs TEXT NULL,
		statut VARCHAR(20) NOT NULL DEFAULT 'en_attente',
		created_by BIGINT UNSIGNED NULL,
		validated_by BIGINT UNSIGNED NULL,
		validated_at DATETIME NULL,
		created_at DATETIME NOT NULL,
		updated_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY resident_no (resident_no),
		KEY statut (statut),
		KEY nom_dob (nom, date_naissance)
	) $c;");

	dbDelta("CREATE TABLE {$p}cards (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		card_no VARCHAR(20) NOT NULL,
		resident_id BIGINT UNSIGNED NOT NULL,
		date_delivrance DATE NOT NULL,
		date_expiration DATE NOT NULL,
		categorie VARCHAR(20) NOT NULL DEFAULT 'membre',
		statut VARCHAR(20) NOT NULL DEFAULT 'active',
		token CHAR(32) NOT NULL,
		created_by BIGINT UNSIGNED NULL,
		created_at DATETIME NOT NULL,
		updated_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY card_no (card_no),
		UNIQUE KEY token (token),
		KEY resident_id (resident_id),
		KEY statut (statut)
	) $c;");

	dbDelta("CREATE TABLE {$p}contributions (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		card_id BIGINT UNSIGNED NULL,
		resident_id BIGINT UNSIGNED NOT NULL,
		montant DECIMAL(12,2) NOT NULL DEFAULT 0,
		devise VARCHAR(3) NOT NULL DEFAULT 'XOF',
		date_paiement DATE NOT NULL,
		note VARCHAR(255) NOT NULL DEFAULT '',
		recorded_by BIGINT UNSIGNED NULL,
		created_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		KEY card_id (card_id),
		KEY resident_id (resident_id)
	) $c;");

	dbDelta("CREATE TABLE {$p}requests (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		resident_id BIGINT UNSIGNED NOT NULL,
		message TEXT NOT NULL,
		statut VARCHAR(20) NOT NULL DEFAULT 'nouvelle',
		created_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		KEY statut (statut),
		KEY resident_id (resident_id)
	) $c;");

	dbDelta("CREATE TABLE {$p}audit (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		user_id BIGINT UNSIGNED NULL,
		action VARCHAR(40) NOT NULL,
		entity VARCHAR(20) NOT NULL,
		entity_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
		details TEXT NULL,
		ip VARCHAR(45) NOT NULL DEFAULT '',
		created_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		KEY entity (entity, entity_id),
		KEY created_at (created_at)
	) $c;");
}

function ccrb_caps() {
	return array('ccrb_access', 'ccrb_view', 'ccrb_create', 'ccrb_edit', 'ccrb_validate', 'ccrb_cards', 'ccrb_contributions', 'ccrb_export', 'ccrb_admin');
}

function ccrb_install_roles() {
	add_role('ccrb_agent', 'Agent CCRB', array(
		'read' => 1, 'ccrb_access' => 1, 'ccrb_view' => 1, 'ccrb_create' => 1,
	));
	add_role('ccrb_responsable', 'Responsable CCRB', array(
		'read' => 1, 'ccrb_access' => 1, 'ccrb_view' => 1, 'ccrb_create' => 1,
		'ccrb_edit' => 1, 'ccrb_validate' => 1, 'ccrb_cards' => 1,
		'ccrb_contributions' => 1, 'ccrb_export' => 1,
	));
	$admin = get_role('administrator');
	if ($admin) {
		foreach (ccrb_caps() as $cap) {
			$admin->add_cap($cap);
		}
	}
}

function ccrb_install_pages() {
	if (get_option('ccrb_page_verification')) {
		return;
	}
	$id = wp_insert_post(array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => 'Vérification',
		'post_name'    => 'verification',
		'post_content' => '[ccrb_verification]',
	));
	if ($id && ! is_wp_error($id)) {
		update_option('ccrb_page_verification', $id);
	}
}
