<?php
defined('ABSPATH') || exit;

/* ------------------------------------------------------------------ */
/* Card verification route: /carte/{token}/                            */
/* ------------------------------------------------------------------ */

add_action('init', 'ccrb_rewrite_rules');
add_filter('query_vars', 'ccrb_query_vars');
add_action('template_redirect', 'ccrb_card_verify_page');

function ccrb_rewrite_rules() {
	add_rewrite_tag('%ccrb_card_token%', '([A-Za-z0-9]{32})');
	add_rewrite_rule('^carte/([A-Za-z0-9]{32})/?$', 'index.php?ccrb_card_token=$matches[1]', 'top');
}

function ccrb_query_vars($vars) {
	$vars[] = 'ccrb_card_token';
	return $vars;
}

function ccrb_card_verify_url($card) {
	return home_url('/carte/' . $card->token . '/');
}

function ccrb_card_verify_page() {
	$token = get_query_var('ccrb_card_token');
	if (! $token) {
		return;
	}
	$card = ccrb_get_card_by_token($token);
	status_header($card ? 200 : 404);
	header('X-Robots-Tag: noindex, nofollow');
	$r = $card ? ccrb_get_resident($card->resident_id) : null;
	$eff = $card ? ccrb_effective_card_status($card) : null;
	$labels = array('active' => 'CARTE VALIDE', 'expiree' => 'CARTE EXPIRÉE', 'desactivee' => 'CARTE DÉSACTIVÉE', 'remplacee' => 'CARTE REMPLACÉE');
	$colors = array('active' => '#0f7b3f', 'expiree' => '#9a7b0a', 'desactivee' => '#8a1f1f', 'remplacee' => '#555');
	$photo = $r && $r->photo_id ? wp_get_attachment_image_url($r->photo_id, 'medium') : '';
	?><!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow"><title>Vérification carte — CCRB</title>
<style>
	body{margin:0;font-family:-apple-system,Arial,sans-serif;background:#f0f0f1;display:flex;justify-content:center;padding:24px;box-sizing:border-box}
	.box{background:#fff;border-radius:12px;max-width:420px;width:100%;padding:28px;box-shadow:0 2px 12px rgba(0,0,0,.08);text-align:center;height:fit-content}
	.org{font-size:13px;font-weight:700;letter-spacing:.5px;color:#333}
	.org small{display:block;font-weight:400;color:#777;margin-top:2px}
	.badge{display:inline-block;color:#fff;font-weight:700;padding:8px 18px;border-radius:20px;margin:18px 0;font-size:14px}
	.badge.bad{background:#8a1f1f}
	.photo{width:110px;height:130px;object-fit:cover;border-radius:8px;border:1px solid #ddd}
	.name{font-size:20px;font-weight:700;margin:12px 0 2px}
	.no{color:#555;font-size:14px}
	table{margin:16px auto 0;border-collapse:collapse;font-size:14px;text-align:left}
	td{padding:5px 12px;border-bottom:1px solid #eee}
	td:first-child{color:#777}
</style></head><body><div class="box">
	<div class="org">CONSEIL DES CAMEROUNAIS RÉSIDENTS AU BÉNIN<small>Vérification de carte communautaire</small></div>
	<?php if ($card) : ?>
		<div><span class="badge" style="background:<?php echo esc_attr($colors[$eff] ?? '#555'); ?>"><?php echo esc_html($labels[$eff] ?? 'INCONNU'); ?></span></div>
		<?php if ($photo) : ?><img class="photo" src="<?php echo esc_url($photo); ?>" alt=""><?php endif; ?>
		<div class="name"><?php echo esc_html($r->nom . ' ' . $r->prenoms); ?></div>
		<div class="no"><?php echo esc_html($card->card_no); ?></div>
		<table>
			<tr><td>N° résident</td><td><?php echo esc_html($r->resident_no); ?></td></tr>
			<tr><td>Délivrée le</td><td><?php echo esc_html(date_i18n('d/m/Y', strtotime($card->date_delivrance))); ?></td></tr>
			<tr><td>Expire le</td><td><?php echo esc_html(date_i18n('d/m/Y', strtotime($card->date_expiration))); ?></td></tr>
		</table>
	<?php else : ?>
		<div><span class="badge bad">CARTE INCONNUE</span></div>
		<p>Ce code ne correspond à aucune carte enregistrée par le CCRB.</p>
	<?php endif; ?>
</div></body></html>
	<?php
	exit;
}

/* ------------------------------------------------------------------ */
/* Rate limiting (public endpoints)                                    */
/* ------------------------------------------------------------------ */

function ccrb_rate_limited($key = 'verify', $max = 30) {
	$ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'x';
	$tkey = 'ccrb_rl_' . $key . '_' . md5($ip);
	$n = (int) get_transient($tkey);
	if ($n >= $max) {
		return true;
	}
	set_transient($tkey, $n + 1, HOUR_IN_SECONDS);
	return false;
}

/* ------------------------------------------------------------------ */
/* Shortcode [ccrb_verification] — resident self-check                 */
/* ------------------------------------------------------------------ */

add_shortcode('ccrb_verification', 'ccrb_shortcode_verification');
add_action('admin_post_ccrb_correction', 'ccrb_handle_correction');
add_action('admin_post_nopriv_ccrb_correction', 'ccrb_handle_correction');

function ccrb_shortcode_verification() {
	wp_enqueue_style('ccrb-public', CCRB_URL . 'assets/ccrb.css', array(), CCRB_VERSION);
	ob_start();
	$msg = '';
	$result = null;
	$checked = false;

	if (isset($_POST['ccrb_verify']) && wp_verify_nonce($_POST['ccrb_nonce'] ?? '', 'ccrb_verify')) {
		$checked = true;
		if (ccrb_rate_limited('verify')) {
			$msg = 'Trop de tentatives. Réessayez plus tard.';
		} else {
			$no = sanitize_text_field(wp_unslash($_POST['resident_no'] ?? ''));
			$dob = sanitize_text_field(wp_unslash($_POST['date_naissance'] ?? ''));
			$r = ccrb_get_resident_by_no($no);
			if ($r && $r->date_naissance === $dob && $r->statut !== 'desactive') {
				$result = $r;
			} elseif ($r && $r->statut === 'desactive') {
				$msg = 'Ce dossier est désactivé. Contactez le CCRB.';
			}
		}
	}
	?>
	<div class="ccrb-public">
		<h3>Vérifier mon inscription</h3>
		<p>Saisissez votre numéro de résident (format CCRB-AA-0000-0000) et votre date de naissance.</p>
		<form method="post" class="ccrb-verify-form">
			<?php wp_nonce_field('ccrb_verify', 'ccrb_nonce'); ?>
			<label>Numéro de résident<br><input type="text" name="resident_no" required placeholder="CCRB-26-0000-0001" value="<?php echo esc_attr($_POST['resident_no'] ?? ''); ?>"></label>
			<label>Date de naissance<br><input type="date" name="date_naissance" required value="<?php echo esc_attr($_POST['date_naissance'] ?? ''); ?>"></label>
			<button type="submit" name="ccrb_verify" value="1">Vérifier</button>
		</form>

		<?php if ($msg) : ?>
			<div class="ccrb-alert ccrb-alert-error"><?php echo esc_html($msg); ?></div>
		<?php elseif ($checked && ! $result) : ?>
			<div class="ccrb-alert ccrb-alert-error">Aucun dossier ne correspond à ces informations. Vérifiez le numéro et la date de naissance, ou rapprochez-vous du CCRB.</div>
		<?php endif; ?>

		<?php if ($result) :
			$card = ccrb_resident_active_card($result->id);
			$any_card = !$card ? ccrb_resident_cards($result->id) : array($card);
			$latest = $card ?: ($any_card[0] ?? null);
			?>
			<div class="ccrb-alert ccrb-alert-ok">
				<p><b>Inscription confirmée</b> — <?php echo esc_html($result->nom . ' ' . $result->prenoms); ?></p>
				<p>Statut de l'inscription : <?php echo $result->statut === 'valide' ? 'Validée' : 'En attente de validation'; ?></p>
				<table class="ccrb-infos">
					<tr><td>N° résident</td><td><?php echo esc_html($result->resident_no); ?></td></tr>
					<tr><td>Nom</td><td><?php echo esc_html($result->nom . ' ' . $result->prenoms); ?></td></tr>
					<tr><td>Né(e) le / à</td><td><?php echo esc_html(date_i18n('d/m/Y', strtotime($result->date_naissance)) . ' — ' . $result->lieu_naissance); ?></td></tr>
					<tr><td>Sexe</td><td><?php echo $result->sexe === 'F' ? 'Féminin' : 'Masculin'; ?></td></tr>
					<tr><td>Nationalité</td><td><?php echo esc_html($result->nationalite); ?></td></tr>
					<tr><td>Adresse au Bénin</td><td><?php echo esc_html($result->adresse_benin); ?></td></tr>
					<tr><td>Téléphone</td><td><?php echo esc_html($result->telephone); ?></td></tr>
					<tr><td>Profession</td><td><?php echo esc_html($result->profession); ?></td></tr>
					<?php if (! empty($result->npi)) : ?><tr><td>NPI étranger</td><td><?php echo esc_html($result->npi); ?></td></tr><?php endif; ?>
					<?php if (! empty($result->groupe_sanguin)) : ?><tr><td>Groupe sanguin</td><td><?php echo esc_html($result->groupe_sanguin); ?></td></tr><?php endif; ?>
				</table>
				<?php if ($latest) :
					$eff = ccrb_effective_card_status($latest); ?>
					<p>Carte communautaire <code><?php echo esc_html($latest->card_no); ?></code> :
						<?php if ($eff === 'active') : ?>
							<b>Active</b> — expire le <?php echo esc_html(date_i18n('d/m/Y', strtotime($latest->date_expiration))); ?>
						<?php elseif ($eff === 'expiree') : ?>
							<b>Expirée</b> depuis le <?php echo esc_html(date_i18n('d/m/Y', strtotime($latest->date_expiration))); ?> — renouvelez-la au siège du CCRB.
						<?php else : ?>
							<b><?php echo esc_html(ucfirst($eff)); ?></b>
						<?php endif; ?>
					</p>
				<?php else : ?>
					<p>Vous ne possédez pas encore de carte communautaire.</p>
				<?php endif; ?>
			</div>

			<details class="ccrb-correction">
				<summary>Signaler une erreur dans mes informations</summary>
				<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
					<input type="hidden" name="action" value="ccrb_correction">
					<?php wp_nonce_field('ccrb_correction_' . $result->id, 'ccrb_nonce'); ?>
					<input type="hidden" name="resident_no" value="<?php echo esc_attr($result->resident_no); ?>">
					<input type="hidden" name="date_naissance" value="<?php echo esc_attr($result->date_naissance); ?>">
					<textarea name="message" required rows="3" placeholder="Décrivez la correction à apporter…"></textarea>
					<button type="submit">Envoyer la demande</button>
				</form>
			</details>
		<?php endif; ?>

		<?php if (isset($_GET['correction']) && $_GET['correction'] === 'ok') : ?>
			<div class="ccrb-alert ccrb-alert-ok">Votre demande de correction a été transmise au CCRB.</div>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

function ccrb_handle_correction() {
	$no = sanitize_text_field(wp_unslash($_POST['resident_no'] ?? ''));
	$dob = sanitize_text_field(wp_unslash($_POST['date_naissance'] ?? ''));
	$message = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
	$r = ccrb_get_resident_by_no($no);
	$back = wp_get_referer() ?: home_url('/');
	if ($r && $r->date_naissance === $dob && $message
		&& wp_verify_nonce($_POST['ccrb_nonce'] ?? '', 'ccrb_correction_' . $r->id)
		&& ! ccrb_rate_limited('correction', 10)) {
		ccrb_add_request($r->id, $message);
		wp_safe_redirect(add_query_arg('correction', 'ok', $back));
	} else {
		wp_safe_redirect($back);
	}
	exit;
}
