<?php
/**
 * Plugin Name: CCRB Registre
 * Description: Registre des residents camerounais au Benin et gestion des cartes communautaires (CCRB).
 * Version: 0.2.0
 * Requires at least: 5.9
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;

define('CCRB_VERSION', '0.2.0');
define('CCRB_PATH', plugin_dir_path(__FILE__));
define('CCRB_URL', plugin_dir_url(__FILE__));

require_once CCRB_PATH . 'includes/schema.php';
require_once CCRB_PATH . 'includes/data.php';
require_once CCRB_PATH . 'includes/admin.php';
require_once CCRB_PATH . 'includes/public.php';

register_activation_hook(__FILE__, 'ccrb_activate');
register_deactivation_hook(__FILE__, 'ccrb_deactivate');

function ccrb_activate() {
	ccrb_install_tables();
	ccrb_install_roles();
	ccrb_install_pages();
	flush_rewrite_rules();
}

function ccrb_deactivate() {
	flush_rewrite_rules();
}

add_action('plugins_loaded', 'ccrb_maybe_upgrade');
function ccrb_maybe_upgrade() {
	if (get_option('ccrb_version') !== CCRB_VERSION) {
		ccrb_install_tables();
		ccrb_install_roles();
		update_option('ccrb_version', CCRB_VERSION);
	}
}
